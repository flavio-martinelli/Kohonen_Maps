function setPath(gitHubDirectory)

addpath(genpath(gitHubDirectory));

end

